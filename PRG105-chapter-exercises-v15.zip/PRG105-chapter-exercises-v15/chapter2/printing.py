# Printing the poem Mary had a little lamb

print("Mary had a little lamb, by Sarah Josepha Hale")
print("Mary had a little lamb,")
print("Its fleece was white as snow;")
print("And everywhere that Mary went")
print("The lamb was sure to go.\n")  # the \n leaves a blank line after this

print("It followed her to school one day")
print("Which was against the rule;")
print("It made the children laugh and play")
print("To see a lamb at school. \n")

print("And so the teacher turned it out,")
print("But still it lingered near;")
print("And waited patiently about")
print("Till Mary did appear. \n")

print("Why does the lamb love Mary so?")
print("The eager children cry;")
print("Why, Mary loves the lamb, you know,")
print("The teacher did reply.")
